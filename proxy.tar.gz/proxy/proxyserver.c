/***********************************************************************************************
* Copyright (C) 2017 Sahana Sadagopan
*
**Redistribution,modification or use of this software in source or binary fors is permitted as long 
*as the files maintain this copyright.Sahana Sadagopan is not liable for any misuse of this material
*
*********************************************************************************************************/
/**
*@file tserve.c.c
*@brief tcp server implementation
*
*This C file provides how to implement TCP Server
*@author Sahana Sadagopan
*@date September 2017
*@version 1.0
*
**/
#include "tserver.h"
#include <pthread.h>
#include <openssl/md5.h>
#include <dirent.h>
#include <time.h>
#include <sys/stat.h>

#define BUF_SIZE 16384
void file_md5_counter(char filename[50],unsigned char md5[50]);

//pthread_mutex_t Cachefile_lock = PTHREAD_MUTEX_INITIALIZER;
int timeinsec;

void findfilesize(char file_name[20],char size[20]){
    FILE *f = fopen(file_name, "rb+");
    fseek(f, 0, SEEK_END);
    long fsize = ftell(f);
    fseek(f, 0, SEEK_SET);
    sprintf(size,"%lu",fsize);
    printf("%s\n",size );
}

int check_pageinfolder(char request[50]){
    DIR *dir;
    struct dirent *fir;
    int cache_flag=0;
    char cwd[1024],md5sum[50];
    char cached_file[50]={0};
    //   getcwd(cwd, sizeof(cwd));
    file_md5_counter(request,md5sum);
    if((dir  = opendir(".")) == NULL) {
        perror("\nUnable to open directory.");
        exit(0);
    }
    printf("The request type is %s\n",request );
    while ((fir=readdir(dir)) != NULL) {
            printf("%s\n", fir->d_name);
            if(strcmp(md5sum,fir->d_name)==0){
            //     strcpy(cached_file,md5sum);
                cache_flag=1;
            //     //return 1;
            }
    }
    closedir(dir);
    if(cache_flag){
        return 1;
    }
    else{
        return 0;
    }
}

void sendcache(char request[50],int sock){
    char buffer_read[1000000],size[50],md5sum[50];
    int sizefile;
    int c,rcvd;
    file_md5_counter(request,md5sum);
    FILE *Cachefile_read=fopen(md5sum,"r+");
    findfilesize(md5sum,size);
    sizefile=atoi(size);
    printf("size of file%d\n",sizefile );
    //while(sizefile>0){
    fread(buffer_read,sizefile,1,Cachefile_read);
    printf("%s\n",buffer_read );
    fclose(Cachefile_read);
        /*if(feof(Cachefile_read)){
            break;
        }*/
        /*else{
            if(sizefile<1000){
                rcvd=sizefile;
                sizefile=sizefile-rcvd;
            }
            else{
                rcvd=1000;
                sizefile=sizefile-rcvd;
            }*/
    if(send(sock,buffer_read,sizefile,0)== -1){
        perror("send");
        exit(1);
    }

       // }
    //}
    
}

void storehostnameip(char request[10],char ip[50]){
    char requestfinal[50];
    strcpy(requestfinal,request);
    strcat(requestfinal,ip);
    FILE *ipfile=fopen("IPCache.txt","ab+");
    printf("file and ip to cache%s\n",requestfinal );
    fwrite(requestfinal,1,strlen(requestfinal)+1,ipfile);
    fclose(ipfile);
}

void file_md5_counter(char filename[50],unsigned char md5[50])
{
  unsigned char md5s[MD5_DIGEST_LENGTH] = {0};
  MD5(filename, strlen(filename), md5s);
  
 // for (int i=0; i < MD5_DIGEST_LENGTH; i++)
  //{
  sprintf(md5,"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",md5s[0],md5s[1],md5s[2],md5s[3],md5s[4],md5s[5],md5s[6],md5s[7],md5s[8],md5s[9],md5s[10],md5s[11],md5s[12],md5s[13],md5s[14],md5s[15]);

  //}  
  //printf("md5sum for %s is %s\n",filename,md5);
  
}

int save_page(char request[50],char message[1000]){
   
    char pagename[50];
    char md5sum[50];
    file_md5_counter(request,md5sum);
    FILE *Cachefile=fopen(md5sum,"ab+");
    //printf("%s\n",md5sum );
    //printf("after here\n");
    
    fwrite(message,1,strlen(message)+1,Cachefile);
    fclose(Cachefile);
    return 0;

}
/*
    Get ip from domain name
 */
 
int hostname_to_ip(char hostname[50] , char* ip)
{
    struct hostent *he;
    struct in_addr **addr_list;
    int i;
    printf("%s\n",hostname );
    //hostname=strtok(hostname,"\0");
    //printf("%zu\n",strlen(hostname) );
    //hostname="umich.edu";
    //printf("%zu\n",strlen(hostname) );
    if ( (he = gethostbyname(hostname))== NULL) 
    {
        // get the host info
        herror("gethostbyname");
        return 1;
    }
 
    addr_list = (struct in_addr **) he->h_addr_list;
     
    for(i = 0; addr_list[i] != NULL; i++) 
    {
        //Return the first one;
        strcpy(ip , inet_ntoa(*addr_list[i]) );
        return 0;
    }
     
    return 1;
}
void checkblockedlist(char request2[70],char ip[30],int sock){
    char buffer[150],size[20];
    //char ret[20];
    printf("in func sock %d\n",sock);
    FILE *blockedlist = fopen("blockedlist.txt","rb+");
    findfilesize("blockedlist.txt",size);
    int sizefile=atoi(size);
    fseek(blockedlist, 0, SEEK_SET);
    fread(buffer,sizefile,1,blockedlist);
    fclose(blockedlist);
    if((strstr(buffer,request2))!=NULL){
    // if(ret !=NULL){
        printf("BAD REQUEST\n");
        char invalid_method[200];
        strcpy(invalid_method,"<html><body><H1>Error 400 Bad Request: Invalid method </H1></body></html>");
        printf("%s\n",invalid_method );
        if(send(sock,invalid_method,strlen(invalid_method),0)== -1){
            perror("send");
            exit(1);
        }
        //sleep(10);
        printf("%s\n",invalid_method );
        close(sock);
        exit(0);
    }
    if((strstr(buffer,ip))!=NULL){
        char invalid_method[200];
        strcpy(invalid_method,"<html><body><H1>Error 400 Bad Request: Invalid method </H1></body></html>");
        printf("%s\n",invalid_method );
        if(send(sock,invalid_method,strlen(invalid_method),0)== -1){
            perror("send");
            exit(1);
        }   
    }
}
/*
 * This will handle connection for each client
 * */
void *connection_handler(void *socket_desc)
{
    size_t len;
    int fd,cache_check_flag=0;
    int chunkRead;
    int chunkWritten;
    //Get the socket descriptor
    char buffer[BUF_SIZE],pagename[20];
    //Timer stuff
    struct stat buf;
    //Server
    struct sockaddr_in connect_server;
    struct hostent *host;
    struct in_addr **addr_list;
    int sock = *(int*)socket_desc,sock_fd;
    char request1[50],request2[50],request3[10],request4[50],request5[50],ip[30],*conffile,*hostname_f;
    int rcvd,count=0,totalBytesRead = 0;;
    char mesg[1000],recvmsg[1000],md5sum [50];
    char reqBuffer[512];
    char day[10],month[10],date[2],justtime1[10],justtime2[10],justtime3[10];
    int timedelete;
    int justtime11,justtime21,justtime31;

    rcvd=recv(sock,mesg,1000,0);
    printf("%s\n",mesg );
    sscanf(mesg,"%s %s %s\nHost: %s",request1,request2,request3,request4);
    printf("request name %s\n",request4 );
    printf("Request 2 %s\n",request2 );
    printf("%s\n",request1);
    if(strcmp(request1,"GET")==0){
        fd = hostname_to_ip(request4, ip);
        //storehostnameip(request2,ip);
        printf("%s\n",ip );
    }
    printf("sock value%d\n",sock );
    
    if(strcmp(request1,"GET")==0){
        checkblockedlist(request4,ip,sock);
        if(check_pageinfolder(request2)==1){
            printf("File exist\n");
            printf("%s\n",request2 );
            char timeoffile[40];
            //retrieve_page();
            //send_page();
            
               // while(1){

            sendcache(request2,sock);
            file_md5_counter(request2,md5sum);
            stat(md5sum,&buf);
            printf("The time is %s",ctime(&buf.st_mtime));
            strcpy(timeoffile,ctime(&buf.st_mtime));
            printf("%s\n",timeoffile );
            sscanf(timeoffile,"%s %s %s %s:%s:%s",day,month,date,justtime1,justtime2,justtime3);
            printf("%s\n",justtime3);
            justtime11=atoi(justtime1);
            justtime21=atoi(justtime2);
            justtime31=atoi(justtime3);
            timedelete=(justtime11*3600)+(justtime21*60)+justtime31;
            printf("time in seconds%d\n",timedelete);
            //if(timeinsec>59){
            //Time stuff
            time_t now;
            struct tm *now_tm;
            int hour;

            now = time(NULL);
            now_tm = localtime(&now);
            hour = (now_tm->tm_hour)*3600;
            int minutes= (now_tm->tm_min)*60;
            int seconds=(now_tm->tm_sec);
            int totaltime = minutes+seconds+hour;
            int diff = totaltime-timedelete;
            printf("Time diff %d\n",diff);
            if(diff>timeinsec){
                remove(md5sum);
                printf("Removed %s\n",md5sum);

            }
                //printf("Timestamp: %d\n",(int)time(NULL));
            //}
            //printf("End here\n");
                //}
            // printf("End here\n");
            close(sock);
        }
        else{
            printf("problem\n");
            if ((sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
                    perror("socket");
                    exit(1);
            }
            connect_server.sin_family = AF_INET;      /* host byte order */
            connect_server.sin_port = htons(80);    /* short, network byte order */
            connect_server.sin_addr.s_addr = inet_addr(ip);
            //bzero(&(connect_server.sin_zero), 8);     /* zero the rest of the struct */

            if (connect(sock_fd, (struct sockaddr *)&connect_server, \
                                                      sizeof(struct sockaddr)) == -1) {
                    perror("connect");
                    exit(1);
            }
            
            else{
                if (send(sock_fd,mesg,strlen(mesg)+1, 0) == -1){
                          perror("send");
                          exit (1);
                }
                rcvd=1;
                //char md5sum[50];
               // file_md5_counter(request2,md5sum);
                //pthread_mutex_lock(&Cachefile_lock);
                //FILE *Cachefile=fopen(md5sum,"wb");
                while(rcvd>=0){
                    //pthread_mutex_lock(&mut);
                    
                    rcvd=recv(sock_fd,recvmsg,1000,0);
                    //pthread_mutex_lock(&Cachefile_lock);
                    
                    //pthread_mutex_unlock(&Cachefile_lock);
                    printf("%d\n",rcvd );
                    if(rcvd>0){
                        if(send(sock,recvmsg,rcvd,0)== -1){
                            perror("send");
                            exit(1);

                        }
                        save_page(request2,recvmsg);
                        //printf("%s\n",mesg );
                    }
                    else{
                        printf("going to break\n");
                         break;
                    }
                    
                }
                //fclose(Cachefile);
                //pthread_mutex_unlock(&Cachefile_lock);
            }
            close(sock);
            close(sock_fd);
        }
        //printf("End here\n");
    }
    //Free the socket pointer
    // close(sock);
    // close(sock_fd);
    //exit(0);
    //pthread_destroy(sniffer_thread);
    //free(socket_desc);
     
    return 0;
}

int main(int argc , char *argv[])
{
    int socket_desc , client_sock , c , *new_sock;
    struct sockaddr_in server , client;
     
    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Could not create socket");
    }
    puts("Socket created");
     
    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(atoi(argv[1]));
    //Reuse Port
    if (setsockopt(socket_desc, SOL_SOCKET, SO_REUSEADDR, &(int){ 1 }, sizeof(int)) < 0)
        perror("setsockopt(SO_REUSEADDR) failed"); 

    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    {
        //print the error message
        perror("bind failed. Error");
        return 1;
    }
    puts("bind done");
     
    //Listen
    listen(socket_desc , 3);
     
    //Accept and incoming connection
    puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);
    timeinsec=atoi(argv[2]);
     
    //Accept and incoming connection
    //puts("Waiting for incoming connections...");
    c = sizeof(struct sockaddr_in);
    while( (client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c)) )
    {
        puts("Connection accepted");
         
        pthread_t sniffer_thread;
        new_sock = malloc(1);
        *new_sock = client_sock;
         
        if( pthread_create( &sniffer_thread , NULL ,  connection_handler , (void*) new_sock) < 0)
        {
            perror("could not create thread");
            return 1;
        }
         
        //Now join the thread , so that we dont terminate before the thread
        pthread_join( sniffer_thread , NULL);
        puts("Handler assigned");


    }
    close(client_sock);
    if (client_sock < 0)
    {
        perror("accept failed");
        return 1;
    }
    
    return 0;
}
 
